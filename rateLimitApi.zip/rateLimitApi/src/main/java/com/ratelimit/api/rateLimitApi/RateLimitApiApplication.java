package com.ratelimit.api.rateLimitApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateLimitApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RateLimitApiApplication.class, args);
	}

}
